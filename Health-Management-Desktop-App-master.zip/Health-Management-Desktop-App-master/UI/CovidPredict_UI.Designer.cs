﻿
namespace HMA
{
    partial class CovidPredict_UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Patientlb = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.chestchk = new System.Windows.Forms.CheckBox();
            this.painchk = new System.Windows.Forms.CheckBox();
            this.Loosechk = new System.Windows.Forms.CheckBox();
            this.sorethrtchk = new System.Windows.Forms.CheckBox();
            this.oxychk = new System.Windows.Forms.CheckBox();
            this.nosechk = new System.Windows.Forms.CheckBox();
            this.breathingchk = new System.Windows.Forms.CheckBox();
            this.smellchk = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Resultlb = new System.Windows.Forms.Label();
            this.Yellowpicbox = new System.Windows.Forms.PictureBox();
            this.GreenPicbox = new System.Windows.Forms.PictureBox();
            this.Redpicbox = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SeeAptpicbox = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.logoutpicbox = new System.Windows.Forms.PictureBox();
            this.Bloodbankpicbox = new System.Windows.Forms.PictureBox();
            this.Medhistorypicbox = new System.Windows.Forms.PictureBox();
            this.BookAptPicbox = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenPicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoutpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bloodbankpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Medhistorypicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAptPicbox)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.SeeAptpicbox);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.logoutpicbox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.Bloodbankpicbox);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Medhistorypicbox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.BookAptPicbox);
            this.panel1.Controls.Add(this.Patientlb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(219, 742);
            this.panel1.TabIndex = 48;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(67, 308);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 44);
            this.label12.TabIndex = 26;
            this.label12.Text = "See \r\nAppoinment";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(67, 580);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 24);
            this.label7.TabIndex = 14;
            this.label7.Text = "Logout";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(64, 494);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 24);
            this.label6.TabIndex = 12;
            this.label6.Text = "Blood Bank";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(67, 390);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 48);
            this.label4.TabIndex = 8;
            this.label4.Text = "Medical \r\n History";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(67, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 44);
            this.label3.TabIndex = 6;
            this.label3.Text = "Book \r\nAppointment";
            // 
            // Patientlb
            // 
            this.Patientlb.AutoSize = true;
            this.Patientlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Patientlb.ForeColor = System.Drawing.Color.White;
            this.Patientlb.Location = new System.Drawing.Point(14, 122);
            this.Patientlb.Name = "Patientlb";
            this.Patientlb.Size = new System.Drawing.Size(99, 25);
            this.Patientlb.TabIndex = 4;
            this.Patientlb.Text = "Patient ";
            this.Patientlb.Click += new System.EventHandler(this.Patientlb_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Yellowpicbox);
            this.panel2.Controls.Add(this.GreenPicbox);
            this.panel2.Controls.Add(this.Resultlb);
            this.panel2.Controls.Add(this.Redpicbox);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.chestchk);
            this.panel2.Controls.Add(this.painchk);
            this.panel2.Controls.Add(this.Loosechk);
            this.panel2.Controls.Add(this.sorethrtchk);
            this.panel2.Controls.Add(this.oxychk);
            this.panel2.Controls.Add(this.nosechk);
            this.panel2.Controls.Add(this.breathingchk);
            this.panel2.Controls.Add(this.smellchk);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(459, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(521, 727);
            this.panel2.TabIndex = 27;
            // 
            // button1
            // 
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(303, 507);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 48);
            this.button1.TabIndex = 58;
            this.button1.Text = "SUBMIT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // chestchk
            // 
            this.chestchk.AutoSize = true;
            this.chestchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chestchk.Location = new System.Drawing.Point(56, 466);
            this.chestchk.Name = "chestchk";
            this.chestchk.Size = new System.Drawing.Size(121, 27);
            this.chestchk.TabIndex = 57;
            this.chestchk.Text = "Chest pain";
            this.chestchk.UseVisualStyleBackColor = true;
            this.chestchk.CheckedChanged += new System.EventHandler(this.chestchk_CheckedChanged);
            // 
            // painchk
            // 
            this.painchk.AutoSize = true;
            this.painchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.painchk.Location = new System.Drawing.Point(56, 418);
            this.painchk.Name = "painchk";
            this.painchk.Size = new System.Drawing.Size(166, 27);
            this.painchk.TabIndex = 56;
            this.painchk.Text = "Aches and pains";
            this.painchk.UseVisualStyleBackColor = true;
            this.painchk.CheckedChanged += new System.EventHandler(this.painchk_CheckedChanged);
            // 
            // Loosechk
            // 
            this.Loosechk.AutoSize = true;
            this.Loosechk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Loosechk.Location = new System.Drawing.Point(56, 366);
            this.Loosechk.Name = "Loosechk";
            this.Loosechk.Size = new System.Drawing.Size(128, 27);
            this.Loosechk.TabIndex = 55;
            this.Loosechk.Text = "Loose stool";
            this.Loosechk.UseVisualStyleBackColor = true;
            this.Loosechk.CheckedChanged += new System.EventHandler(this.Loosechk_CheckedChanged);
            // 
            // sorethrtchk
            // 
            this.sorethrtchk.AutoSize = true;
            this.sorethrtchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sorethrtchk.Location = new System.Drawing.Point(56, 311);
            this.sorethrtchk.Name = "sorethrtchk";
            this.sorethrtchk.Size = new System.Drawing.Size(128, 27);
            this.sorethrtchk.TabIndex = 54;
            this.sorethrtchk.Text = "Sore throat";
            this.sorethrtchk.UseVisualStyleBackColor = true;
            this.sorethrtchk.CheckedChanged += new System.EventHandler(this.sorethrtchk_CheckedChanged);
            // 
            // oxychk
            // 
            this.oxychk.AutoSize = true;
            this.oxychk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oxychk.Location = new System.Drawing.Point(56, 252);
            this.oxychk.Name = "oxychk";
            this.oxychk.Size = new System.Drawing.Size(301, 27);
            this.oxychk.TabIndex = 53;
            this.oxychk.Text = "Oxygen level decreasing rapidly";
            this.oxychk.UseVisualStyleBackColor = true;
            this.oxychk.CheckedChanged += new System.EventHandler(this.oxychk_CheckedChanged);
            // 
            // nosechk
            // 
            this.nosechk.AutoSize = true;
            this.nosechk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nosechk.Location = new System.Drawing.Point(56, 204);
            this.nosechk.Name = "nosechk";
            this.nosechk.Size = new System.Drawing.Size(133, 27);
            this.nosechk.TabIndex = 52;
            this.nosechk.Text = "Runny Nose";
            this.nosechk.UseVisualStyleBackColor = true;
            this.nosechk.CheckedChanged += new System.EventHandler(this.nosechk_CheckedChanged);
            // 
            // breathingchk
            // 
            this.breathingchk.AutoSize = true;
            this.breathingchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breathingchk.Location = new System.Drawing.Point(56, 151);
            this.breathingchk.Name = "breathingchk";
            this.breathingchk.Size = new System.Drawing.Size(229, 27);
            this.breathingchk.TabIndex = 51;
            this.breathingchk.Text = "Difficulties in breathing";
            this.breathingchk.UseVisualStyleBackColor = true;
            this.breathingchk.CheckedChanged += new System.EventHandler(this.breathingchk_CheckedChanged);
            // 
            // smellchk
            // 
            this.smellchk.AutoSize = true;
            this.smellchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smellchk.Location = new System.Drawing.Point(56, 98);
            this.smellchk.Name = "smellchk";
            this.smellchk.Size = new System.Drawing.Size(201, 27);
            this.smellchk.TabIndex = 50;
            this.smellchk.Text = "Loss of test or smell";
            this.smellchk.UseVisualStyleBackColor = true;
            this.smellchk.CheckedChanged += new System.EventHandler(this.smellchk_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 15F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(8, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(349, 26);
            this.label1.TabIndex = 27;
            this.label1.Text = "Select the symptoms you have :";
            // 
            // Resultlb
            // 
            this.Resultlb.AutoSize = true;
            this.Resultlb.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resultlb.Location = new System.Drawing.Point(245, 607);
            this.Resultlb.Name = "Resultlb";
            this.Resultlb.Size = new System.Drawing.Size(0, 46);
            this.Resultlb.TabIndex = 59;
            // 
            // Yellowpicbox
            // 
            this.Yellowpicbox.Image = global::HMA.Properties.Resources.yellow;
            this.Yellowpicbox.Location = new System.Drawing.Point(3, 561);
            this.Yellowpicbox.Name = "Yellowpicbox";
            this.Yellowpicbox.Size = new System.Drawing.Size(201, 162);
            this.Yellowpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Yellowpicbox.TabIndex = 61;
            this.Yellowpicbox.TabStop = false;
            this.Yellowpicbox.Visible = false;
            // 
            // GreenPicbox
            // 
            this.GreenPicbox.Image = global::HMA.Properties.Resources.alert_128;
            this.GreenPicbox.Location = new System.Drawing.Point(3, 561);
            this.GreenPicbox.Name = "GreenPicbox";
            this.GreenPicbox.Size = new System.Drawing.Size(201, 162);
            this.GreenPicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GreenPicbox.TabIndex = 60;
            this.GreenPicbox.TabStop = false;
            this.GreenPicbox.Visible = false;
            // 
            // Redpicbox
            // 
            this.Redpicbox.Image = global::HMA.Properties.Resources.redalert;
            this.Redpicbox.Location = new System.Drawing.Point(0, 561);
            this.Redpicbox.Name = "Redpicbox";
            this.Redpicbox.Size = new System.Drawing.Size(201, 162);
            this.Redpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Redpicbox.TabIndex = 59;
            this.Redpicbox.TabStop = false;
            this.Redpicbox.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HMA.Properties.Resources.covid_19_4975604_960_720;
            this.pictureBox1.Location = new System.Drawing.Point(215, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(980, 745);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // SeeAptpicbox
            // 
            this.SeeAptpicbox.Image = global::HMA.Properties.Resources.appointment;
            this.SeeAptpicbox.Location = new System.Drawing.Point(19, 308);
            this.SeeAptpicbox.Name = "SeeAptpicbox";
            this.SeeAptpicbox.Size = new System.Drawing.Size(42, 56);
            this.SeeAptpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SeeAptpicbox.TabIndex = 25;
            this.SeeAptpicbox.TabStop = false;
            this.SeeAptpicbox.Click += new System.EventHandler(this.SeeAptpicbox_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Teal;
            this.pictureBox4.Image = global::HMA.Properties.Resources.L;
            this.pictureBox4.Location = new System.Drawing.Point(12, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(101, 101);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // logoutpicbox
            // 
            this.logoutpicbox.Image = global::HMA.Properties.Resources.logout;
            this.logoutpicbox.Location = new System.Drawing.Point(19, 564);
            this.logoutpicbox.Name = "logoutpicbox";
            this.logoutpicbox.Size = new System.Drawing.Size(42, 56);
            this.logoutpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoutpicbox.TabIndex = 13;
            this.logoutpicbox.TabStop = false;
            this.logoutpicbox.Click += new System.EventHandler(this.logoutpicbox_Click);
            // 
            // Bloodbankpicbox
            // 
            this.Bloodbankpicbox.Image = global::HMA.Properties.Resources.blood_bank;
            this.Bloodbankpicbox.Location = new System.Drawing.Point(16, 469);
            this.Bloodbankpicbox.Name = "Bloodbankpicbox";
            this.Bloodbankpicbox.Size = new System.Drawing.Size(42, 56);
            this.Bloodbankpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Bloodbankpicbox.TabIndex = 11;
            this.Bloodbankpicbox.TabStop = false;
            this.Bloodbankpicbox.Click += new System.EventHandler(this.Bloodbankpicbox_Click);
            // 
            // Medhistorypicbox
            // 
            this.Medhistorypicbox.Image = global::HMA.Properties.Resources.medical_history;
            this.Medhistorypicbox.Location = new System.Drawing.Point(19, 384);
            this.Medhistorypicbox.Name = "Medhistorypicbox";
            this.Medhistorypicbox.Size = new System.Drawing.Size(42, 56);
            this.Medhistorypicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Medhistorypicbox.TabIndex = 7;
            this.Medhistorypicbox.TabStop = false;
            this.Medhistorypicbox.Click += new System.EventHandler(this.Medhistorypicbox_Click);
            // 
            // BookAptPicbox
            // 
            this.BookAptPicbox.Image = global::HMA.Properties.Resources.appointment_book;
            this.BookAptPicbox.Location = new System.Drawing.Point(19, 237);
            this.BookAptPicbox.Name = "BookAptPicbox";
            this.BookAptPicbox.Size = new System.Drawing.Size(42, 56);
            this.BookAptPicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BookAptPicbox.TabIndex = 5;
            this.BookAptPicbox.TabStop = false;
            this.BookAptPicbox.Click += new System.EventHandler(this.BookAptPicbox_Click);
            // 
            // CovidPredict_UI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1195, 742);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CovidPredict_UI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CovidPredict_UI";
//            this.Load += new System.EventHandler(this.CovidPredict_UI_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenPicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoutpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bloodbankpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Medhistorypicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAptPicbox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox SeeAptpicbox;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox logoutpicbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox Bloodbankpicbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox Medhistorypicbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox BookAptPicbox;
        private System.Windows.Forms.Label Patientlb;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chestchk;
        private System.Windows.Forms.CheckBox painchk;
        private System.Windows.Forms.CheckBox Loosechk;
        private System.Windows.Forms.CheckBox sorethrtchk;
        private System.Windows.Forms.CheckBox oxychk;
        private System.Windows.Forms.CheckBox nosechk;
        private System.Windows.Forms.CheckBox breathingchk;
        private System.Windows.Forms.CheckBox smellchk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Resultlb;
        private System.Windows.Forms.PictureBox GreenPicbox;
        private System.Windows.Forms.PictureBox Redpicbox;
        private System.Windows.Forms.PictureBox Yellowpicbox;
    }
}