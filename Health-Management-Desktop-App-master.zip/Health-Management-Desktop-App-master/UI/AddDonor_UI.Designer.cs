﻿
namespace HMA
{
    partial class AddDonor_UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Backpicbox = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.AddDoctorpicbox = new System.Windows.Forms.PictureBox();
            this.Adminlb = new System.Windows.Forms.Label();
            this.Dfnametxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DBloodGrpcb = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Dlnametxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Dphontxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Dareatxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Dcitytxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Addbtn = new System.Windows.Forms.Button();
            this.Editvbtn = new System.Windows.Forms.Button();
            this.Removebtn = new System.Windows.Forms.Button();
            this.DonorDGV = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Backpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddDoctorpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DonorDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.Backpicbox);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.AddDoctorpicbox);
            this.panel1.Controls.Add(this.Adminlb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(228, 699);
            this.panel1.TabIndex = 36;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Teal;
            this.pictureBox5.Image = global::HMA.Properties.Resources.L;
            this.pictureBox5.Location = new System.Drawing.Point(39, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(101, 101);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 24;
            this.pictureBox5.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(83, 618);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 25);
            this.label8.TabIndex = 14;
            this.label8.Text = "Back";
            // 
            // Backpicbox
            // 
            this.Backpicbox.Image = global::HMA.Properties.Resources.back_arrow;
            this.Backpicbox.Location = new System.Drawing.Point(21, 604);
            this.Backpicbox.Name = "Backpicbox";
            this.Backpicbox.Size = new System.Drawing.Size(48, 67);
            this.Backpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Backpicbox.TabIndex = 13;
            this.Backpicbox.TabStop = false;
            this.Backpicbox.Click += new System.EventHandler(this.Backpicbox_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(34, 404);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(135, 25);
            this.label11.TabIndex = 8;
            this.label11.Text = "Add Doctor";
            // 
            // AddDoctorpicbox
            // 
            this.AddDoctorpicbox.Image = global::HMA.Properties.Resources.doctor;
            this.AddDoctorpicbox.Location = new System.Drawing.Point(56, 294);
            this.AddDoctorpicbox.Name = "AddDoctorpicbox";
            this.AddDoctorpicbox.Size = new System.Drawing.Size(81, 91);
            this.AddDoctorpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddDoctorpicbox.TabIndex = 7;
            this.AddDoctorpicbox.TabStop = false;
            this.AddDoctorpicbox.Click += new System.EventHandler(this.AddDoctorpicbox_Click);
            // 
            // Adminlb
            // 
            this.Adminlb.AutoSize = true;
            this.Adminlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adminlb.ForeColor = System.Drawing.Color.White;
            this.Adminlb.Location = new System.Drawing.Point(52, 133);
            this.Adminlb.Name = "Adminlb";
            this.Adminlb.Size = new System.Drawing.Size(85, 25);
            this.Adminlb.TabIndex = 4;
            this.Adminlb.Text = "Admin";
            this.Adminlb.Click += new System.EventHandler(this.Adminlb_Click);
            // 
            // Dfnametxt
            // 
            this.Dfnametxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Dfnametxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Dfnametxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dfnametxt.ForeColor = System.Drawing.Color.Black;
            this.Dfnametxt.Location = new System.Drawing.Point(254, 54);
            this.Dfnametxt.Multiline = true;
            this.Dfnametxt.Name = "Dfnametxt";
            this.Dfnametxt.Size = new System.Drawing.Size(355, 46);
            this.Dfnametxt.TabIndex = 171;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(249, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 29);
            this.label2.TabIndex = 170;
            this.label2.Text = "First Name :";
            // 
            // DBloodGrpcb
            // 
            this.DBloodGrpcb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.DBloodGrpcb.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DBloodGrpcb.FormattingEnabled = true;
            this.DBloodGrpcb.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.DBloodGrpcb.Location = new System.Drawing.Point(642, 142);
            this.DBloodGrpcb.Name = "DBloodGrpcb";
            this.DBloodGrpcb.Size = new System.Drawing.Size(175, 39);
            this.DBloodGrpcb.TabIndex = 175;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(646, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 29);
            this.label7.TabIndex = 174;
            this.label7.Text = "Blood Group:";
            // 
            // Dlnametxt
            // 
            this.Dlnametxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Dlnametxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Dlnametxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dlnametxt.ForeColor = System.Drawing.Color.Black;
            this.Dlnametxt.Location = new System.Drawing.Point(642, 54);
            this.Dlnametxt.Multiline = true;
            this.Dlnametxt.Name = "Dlnametxt";
            this.Dlnametxt.Size = new System.Drawing.Size(355, 46);
            this.Dlnametxt.TabIndex = 173;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(637, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 29);
            this.label3.TabIndex = 172;
            this.label3.Text = "Last Name :";
            // 
            // Dphontxt
            // 
            this.Dphontxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Dphontxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Dphontxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dphontxt.ForeColor = System.Drawing.Color.Black;
            this.Dphontxt.Location = new System.Drawing.Point(254, 135);
            this.Dphontxt.Multiline = true;
            this.Dphontxt.Name = "Dphontxt";
            this.Dphontxt.Size = new System.Drawing.Size(355, 46);
            this.Dphontxt.TabIndex = 177;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(249, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 29);
            this.label1.TabIndex = 176;
            this.label1.Text = "Phone No:";
            // 
            // Dareatxt
            // 
            this.Dareatxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Dareatxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Dareatxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dareatxt.ForeColor = System.Drawing.Color.Black;
            this.Dareatxt.Location = new System.Drawing.Point(651, 225);
            this.Dareatxt.Multiline = true;
            this.Dareatxt.Name = "Dareatxt";
            this.Dareatxt.Size = new System.Drawing.Size(355, 46);
            this.Dareatxt.TabIndex = 181;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(646, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 29);
            this.label4.TabIndex = 180;
            this.label4.Text = "Area:";
            // 
            // Dcitytxt
            // 
            this.Dcitytxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Dcitytxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Dcitytxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dcitytxt.ForeColor = System.Drawing.Color.Black;
            this.Dcitytxt.Location = new System.Drawing.Point(254, 225);
            this.Dcitytxt.Multiline = true;
            this.Dcitytxt.Name = "Dcitytxt";
            this.Dcitytxt.Size = new System.Drawing.Size(355, 46);
            this.Dcitytxt.TabIndex = 179;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(249, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 29);
            this.label5.TabIndex = 178;
            this.label5.Text = "City :";
            // 
            // Addbtn
            // 
            this.Addbtn.BackColor = System.Drawing.Color.Teal;
            this.Addbtn.FlatAppearance.BorderSize = 2;
            this.Addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbtn.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.White;
            this.Addbtn.Location = new System.Drawing.Point(337, 277);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(170, 48);
            this.Addbtn.TabIndex = 182;
            this.Addbtn.Text = "ADD";
            this.Addbtn.UseVisualStyleBackColor = false;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // Editvbtn
            // 
            this.Editvbtn.BackColor = System.Drawing.Color.Teal;
            this.Editvbtn.FlatAppearance.BorderSize = 2;
            this.Editvbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Editvbtn.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editvbtn.ForeColor = System.Drawing.Color.White;
            this.Editvbtn.Location = new System.Drawing.Point(574, 277);
            this.Editvbtn.Name = "Editvbtn";
            this.Editvbtn.Size = new System.Drawing.Size(170, 48);
            this.Editvbtn.TabIndex = 183;
            this.Editvbtn.Text = "EDIT";
            this.Editvbtn.UseVisualStyleBackColor = false;
            this.Editvbtn.Click += new System.EventHandler(this.Editvbtn_Click);
            // 
            // Removebtn
            // 
            this.Removebtn.BackColor = System.Drawing.Color.Teal;
            this.Removebtn.FlatAppearance.BorderSize = 2;
            this.Removebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Removebtn.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Removebtn.ForeColor = System.Drawing.Color.White;
            this.Removebtn.Location = new System.Drawing.Point(779, 277);
            this.Removebtn.Name = "Removebtn";
            this.Removebtn.Size = new System.Drawing.Size(170, 48);
            this.Removebtn.TabIndex = 184;
            this.Removebtn.Text = "REMOVE";
            this.Removebtn.UseVisualStyleBackColor = false;
            this.Removebtn.Click += new System.EventHandler(this.Removebtn_Click);
            // 
            // DonorDGV
            // 
            this.DonorDGV.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DonorDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DonorDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DonorDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DonorDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DonorDGV.EnableHeadersVisualStyles = false;
            this.DonorDGV.GridColor = System.Drawing.Color.MidnightBlue;
            this.DonorDGV.Location = new System.Drawing.Point(234, 370);
            this.DonorDGV.Name = "DonorDGV";
            this.DonorDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DonorDGV.RowHeadersVisible = false;
            this.DonorDGV.RowHeadersWidth = 51;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.DonorDGV.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DonorDGV.RowTemplate.Height = 24;
            this.DonorDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DonorDGV.Size = new System.Drawing.Size(962, 317);
            this.DonorDGV.TabIndex = 185;
            this.DonorDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DonorDGV_CellContentClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(610, 344);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 23);
            this.label12.TabIndex = 211;
            this.label12.Text = "Donor List";
            // 
            // AddDonor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1208, 699);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.DonorDGV);
            this.Controls.Add(this.Removebtn);
            this.Controls.Add(this.Editvbtn);
            this.Controls.Add(this.Addbtn);
            this.Controls.Add(this.Dareatxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Dcitytxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Dphontxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DBloodGrpcb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Dlnametxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Dfnametxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddDonor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddDonor";
            this.Load += new System.EventHandler(this.AddDonor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Backpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddDoctorpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DonorDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox Backpicbox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox AddDoctorpicbox;
        private System.Windows.Forms.Label Adminlb;
        private System.Windows.Forms.TextBox Dfnametxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox DBloodGrpcb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Dlnametxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Dphontxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Dareatxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Dcitytxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Button Editvbtn;
        private System.Windows.Forms.Button Removebtn;
        private System.Windows.Forms.DataGridView DonorDGV;
        private System.Windows.Forms.Label label12;
    }
}