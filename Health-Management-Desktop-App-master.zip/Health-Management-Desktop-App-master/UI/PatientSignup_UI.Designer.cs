﻿
namespace HMA
{
    partial class PatientSignup_UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Pfnametxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.Plnametxt = new System.Windows.Forms.TextBox();
            this.Pusertxt = new System.Windows.Forms.TextBox();
            this.Ppasstxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Pcontacttxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Pgendercb = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pheighttxt = new System.Windows.Forms.TextBox();
            this.Pweighttxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Pbgrptxt = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.checkpressureb = new System.Windows.Forms.CheckBox();
            this.checksugerb = new System.Windows.Forms.CheckBox();
            this.checkheartdb = new System.Windows.Forms.CheckBox();
            this.checkgastrickb = new System.Windows.Forms.CheckBox();
            this.checknoneb = new System.Windows.Forms.CheckBox();
            this.checkallergyb = new System.Windows.Forms.CheckBox();
            this.checkanemiab = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Pagetxt = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lime;
            this.pictureBox2.Image = global::HMA.Properties.Resources.v870_tang_36;
            this.pictureBox2.Location = new System.Drawing.Point(-4, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1084, 705);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bauhaus 93", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(260, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 49);
            this.label1.TabIndex = 149;
            this.label1.Text = "Sign Up";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 29);
            this.label2.TabIndex = 150;
            this.label2.Text = "First Name :";
            // 
            // Pfnametxt
            // 
            this.Pfnametxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Pfnametxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pfnametxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pfnametxt.ForeColor = System.Drawing.Color.Black;
            this.Pfnametxt.Location = new System.Drawing.Point(29, 159);
            this.Pfnametxt.Multiline = true;
            this.Pfnametxt.Name = "Pfnametxt";
            this.Pfnametxt.Size = new System.Drawing.Size(355, 46);
            this.Pfnametxt.TabIndex = 151;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(404, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 29);
            this.label3.TabIndex = 152;
            this.label3.Text = "Last Name :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(454, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 29);
            this.label5.TabIndex = 153;
            this.label5.Text = "Password :";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::HMA.Properties.Resources.regpass;
            this.pictureBox4.Location = new System.Drawing.Point(409, 230);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(39, 27);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 154;
            this.pictureBox4.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(29, 412);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 29);
            this.label8.TabIndex = 156;
            this.label8.Text = "Height :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(58, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 29);
            this.label4.TabIndex = 157;
            this.label4.Text = "User Name :";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::HMA.Properties.Resources.reguser;
            this.pictureBox5.Location = new System.Drawing.Point(29, 230);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(23, 25);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 158;
            this.pictureBox5.TabStop = false;
            // 
            // Plnametxt
            // 
            this.Plnametxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Plnametxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Plnametxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Plnametxt.ForeColor = System.Drawing.Color.Black;
            this.Plnametxt.Location = new System.Drawing.Point(409, 159);
            this.Plnametxt.Multiline = true;
            this.Plnametxt.Name = "Plnametxt";
            this.Plnametxt.Size = new System.Drawing.Size(355, 46);
            this.Plnametxt.TabIndex = 159;
            // 
            // Pusertxt
            // 
            this.Pusertxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Pusertxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pusertxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pusertxt.ForeColor = System.Drawing.Color.Black;
            this.Pusertxt.Location = new System.Drawing.Point(29, 266);
            this.Pusertxt.Multiline = true;
            this.Pusertxt.Name = "Pusertxt";
            this.Pusertxt.Size = new System.Drawing.Size(355, 46);
            this.Pusertxt.TabIndex = 160;
            // 
            // Ppasstxt
            // 
            this.Ppasstxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Ppasstxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Ppasstxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ppasstxt.ForeColor = System.Drawing.Color.Black;
            this.Ppasstxt.Location = new System.Drawing.Point(411, 266);
            this.Ppasstxt.Multiline = true;
            this.Ppasstxt.Name = "Ppasstxt";
            this.Ppasstxt.Size = new System.Drawing.Size(355, 46);
            this.Ppasstxt.TabIndex = 161;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(24, 319);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 29);
            this.label6.TabIndex = 162;
            this.label6.Text = "Contact No.";
            // 
            // Pcontacttxt
            // 
            this.Pcontacttxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Pcontacttxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pcontacttxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pcontacttxt.ForeColor = System.Drawing.Color.Black;
            this.Pcontacttxt.Location = new System.Drawing.Point(29, 353);
            this.Pcontacttxt.Multiline = true;
            this.Pcontacttxt.Name = "Pcontacttxt";
            this.Pcontacttxt.Size = new System.Drawing.Size(355, 46);
            this.Pcontacttxt.TabIndex = 163;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(404, 319);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 29);
            this.label7.TabIndex = 164;
            this.label7.Text = "Gender :";
            // 
            // Pgendercb
            // 
            this.Pgendercb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Pgendercb.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pgendercb.FormattingEnabled = true;
            this.Pgendercb.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.Pgendercb.Location = new System.Drawing.Point(409, 353);
            this.Pgendercb.Name = "Pgendercb";
            this.Pgendercb.Size = new System.Drawing.Size(175, 39);
            this.Pgendercb.TabIndex = 165;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(207, 412);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 29);
            this.label11.TabIndex = 166;
            this.label11.Text = "Weight :";
            // 
            // pheighttxt
            // 
            this.pheighttxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.pheighttxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pheighttxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pheighttxt.ForeColor = System.Drawing.Color.Black;
            this.pheighttxt.Location = new System.Drawing.Point(29, 455);
            this.pheighttxt.Multiline = true;
            this.pheighttxt.Name = "pheighttxt";
            this.pheighttxt.Size = new System.Drawing.Size(167, 46);
            this.pheighttxt.TabIndex = 167;
            this.pheighttxt.MouseLeave += new System.EventHandler(this.pheighttxt_MouseLeave);
            this.pheighttxt.MouseHover += new System.EventHandler(this.pheighttxt_MouseHover);
            // 
            // Pweighttxt
            // 
            this.Pweighttxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Pweighttxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pweighttxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pweighttxt.ForeColor = System.Drawing.Color.Black;
            this.Pweighttxt.Location = new System.Drawing.Point(212, 455);
            this.Pweighttxt.Multiline = true;
            this.Pweighttxt.Name = "Pweighttxt";
            this.Pweighttxt.Size = new System.Drawing.Size(172, 46);
            this.Pweighttxt.TabIndex = 168;
            this.Pweighttxt.MouseLeave += new System.EventHandler(this.Pweighttxt_MouseLeave);
            this.Pweighttxt.MouseHover += new System.EventHandler(this.Pweighttxt_MouseHover);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.label9.Font = new System.Drawing.Font("Bodoni MT", 16.2F);
            this.label9.Location = new System.Drawing.Point(333, 460);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 34);
            this.label9.TabIndex = 169;
            this.label9.Text = "Kg";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.label10.Font = new System.Drawing.Font("Bodoni MT", 16.2F);
            this.label10.Location = new System.Drawing.Point(141, 460);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 34);
            this.label10.TabIndex = 170;
            this.label10.Text = "Cm";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(414, 412);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(157, 29);
            this.label12.TabIndex = 171;
            this.label12.Text = "Blood Group :";
            // 
            // Pbgrptxt
            // 
            this.Pbgrptxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Pbgrptxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pbgrptxt.FormattingEnabled = true;
            this.Pbgrptxt.Items.AddRange(new object[] {
            "A+",
            "B+",
            "A-",
            "B-",
            "AB+",
            "AB-",
            "0+",
            "0-"});
            this.Pbgrptxt.Location = new System.Drawing.Point(409, 455);
            this.Pbgrptxt.Name = "Pbgrptxt";
            this.Pbgrptxt.Size = new System.Drawing.Size(187, 39);
            this.Pbgrptxt.TabIndex = 172;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(29, 523);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(301, 28);
            this.label13.TabIndex = 173;
            this.label13.Text = "Select Your Current Dieases :";
            // 
            // checkpressureb
            // 
            this.checkpressureb.AutoSize = true;
            this.checkpressureb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkpressureb.Location = new System.Drawing.Point(28, 555);
            this.checkpressureb.Name = "checkpressureb";
            this.checkpressureb.Size = new System.Drawing.Size(161, 24);
            this.checkpressureb.TabIndex = 174;
            this.checkpressureb.Text = "Blood Pressure";
            this.checkpressureb.UseVisualStyleBackColor = true;
            this.checkpressureb.CheckedChanged += new System.EventHandler(this.checkpressureb_CheckedChanged);
            // 
            // checksugerb
            // 
            this.checksugerb.AutoSize = true;
            this.checksugerb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checksugerb.Location = new System.Drawing.Point(230, 555);
            this.checksugerb.Name = "checksugerb";
            this.checksugerb.Size = new System.Drawing.Size(106, 24);
            this.checksugerb.TabIndex = 175;
            this.checksugerb.Text = "Diabetes";
            this.checksugerb.UseVisualStyleBackColor = true;
            this.checksugerb.CheckedChanged += new System.EventHandler(this.checksugerb_CheckedChanged);
            // 
            // checkheartdb
            // 
            this.checkheartdb.AutoSize = true;
            this.checkheartdb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkheartdb.Location = new System.Drawing.Point(389, 555);
            this.checkheartdb.Name = "checkheartdb";
            this.checkheartdb.Size = new System.Drawing.Size(153, 24);
            this.checkheartdb.TabIndex = 176;
            this.checkheartdb.Text = "Heart Disease";
            this.checkheartdb.UseVisualStyleBackColor = true;
            this.checkheartdb.CheckedChanged += new System.EventHandler(this.checkheartdb_CheckedChanged);
            // 
            // checkgastrickb
            // 
            this.checkgastrickb.AutoSize = true;
            this.checkgastrickb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkgastrickb.Location = new System.Drawing.Point(593, 555);
            this.checkgastrickb.Name = "checkgastrickb";
            this.checkgastrickb.Size = new System.Drawing.Size(93, 24);
            this.checkgastrickb.TabIndex = 177;
            this.checkgastrickb.Text = "Gastric";
            this.checkgastrickb.UseVisualStyleBackColor = true;
            this.checkgastrickb.CheckedChanged += new System.EventHandler(this.checkgastrickb_CheckedChanged);
            // 
            // checknoneb
            // 
            this.checknoneb.AutoSize = true;
            this.checknoneb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checknoneb.Location = new System.Drawing.Point(389, 594);
            this.checknoneb.Name = "checknoneb";
            this.checknoneb.Size = new System.Drawing.Size(74, 24);
            this.checknoneb.TabIndex = 178;
            this.checknoneb.Text = "None";
            this.checknoneb.UseVisualStyleBackColor = true;
            this.checknoneb.CheckedChanged += new System.EventHandler(this.checknoneb_CheckedChanged);
            // 
            // checkallergyb
            // 
            this.checkallergyb.AutoSize = true;
            this.checkallergyb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkallergyb.Location = new System.Drawing.Point(230, 594);
            this.checkallergyb.Name = "checkallergyb";
            this.checkallergyb.Size = new System.Drawing.Size(89, 24);
            this.checkallergyb.TabIndex = 179;
            this.checkallergyb.Text = "Allergy";
            this.checkallergyb.UseVisualStyleBackColor = true;
            this.checkallergyb.CheckedChanged += new System.EventHandler(this.checkallergyb_CheckedChanged);
            // 
            // checkanemiab
            // 
            this.checkanemiab.AutoSize = true;
            this.checkanemiab.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkanemiab.Location = new System.Drawing.Point(28, 594);
            this.checkanemiab.Name = "checkanemiab";
            this.checkanemiab.Size = new System.Drawing.Size(93, 24);
            this.checkanemiab.TabIndex = 180;
            this.checkanemiab.Text = "Anemia";
            this.checkanemiab.UseVisualStyleBackColor = true;
            this.checkanemiab.CheckedChanged += new System.EventHandler(this.checkanemiab_CheckedChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(407, 631);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 48);
            this.button1.TabIndex = 181;
            this.button1.Text = "SUBMIT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Teal;
            this.btnexit.FlatAppearance.BorderSize = 2;
            this.btnexit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnexit.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.ForeColor = System.Drawing.Color.White;
            this.btnexit.Location = new System.Drawing.Point(593, 631);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(173, 48);
            this.btnexit.TabIndex = 182;
            this.btnexit.Text = "EXIT";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(642, 319);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 29);
            this.label14.TabIndex = 183;
            this.label14.Text = "Age :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HMA.Properties.Resources.L;
            this.pictureBox1.Location = new System.Drawing.Point(142, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(112, 82);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Pagetxt
            // 
            this.Pagetxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.Pagetxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pagetxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pagetxt.ForeColor = System.Drawing.Color.Black;
            this.Pagetxt.Location = new System.Drawing.Point(639, 351);
            this.Pagetxt.Multiline = true;
            this.Pagetxt.Name = "Pagetxt";
            this.Pagetxt.Size = new System.Drawing.Size(117, 46);
            this.Pagetxt.TabIndex = 184;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Pagetxt);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.btnexit);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.checkanemiab);
            this.panel1.Controls.Add(this.checkallergyb);
            this.panel1.Controls.Add(this.checknoneb);
            this.panel1.Controls.Add(this.checkgastrickb);
            this.panel1.Controls.Add(this.checkheartdb);
            this.panel1.Controls.Add(this.checksugerb);
            this.panel1.Controls.Add(this.checkpressureb);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.Pbgrptxt);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.Pweighttxt);
            this.panel1.Controls.Add(this.pheighttxt);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.Pgendercb);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Pcontacttxt);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.Ppasstxt);
            this.panel1.Controls.Add(this.Pusertxt);
            this.panel1.Controls.Add(this.Plnametxt);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.Pfnametxt);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(303, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(777, 705);
            this.panel1.TabIndex = 5;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 676);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1079, 26);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(151, 20);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // PatientSignup_UI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1079, 702);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PatientSignup_UI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration";
            this.Load += new System.EventHandler(this.Registration_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Pfnametxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox Plnametxt;
        private System.Windows.Forms.TextBox Pusertxt;
        private System.Windows.Forms.TextBox Ppasstxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Pcontacttxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Pgendercb;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox pheighttxt;
        private System.Windows.Forms.TextBox Pweighttxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox Pbgrptxt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox checkpressureb;
        private System.Windows.Forms.CheckBox checksugerb;
        private System.Windows.Forms.CheckBox checkheartdb;
        private System.Windows.Forms.CheckBox checkgastrickb;
        private System.Windows.Forms.CheckBox checknoneb;
        private System.Windows.Forms.CheckBox checkallergyb;
        private System.Windows.Forms.CheckBox checkanemiab;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Pagetxt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}