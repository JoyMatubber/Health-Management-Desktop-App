﻿
namespace HMA
{
    partial class TreatmentUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label4 = new System.Windows.Forms.Label();
            this.Doctorlb = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Logoutpicbox = new System.Windows.Forms.PictureBox();
            this.Aptpicbox = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.TreatDGV = new System.Windows.Forms.DataGridView();
            this.PrevrecordBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DoneBtn = new System.Windows.Forms.Button();
            this.GiveTrttxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.patBgrplb = new System.Windows.Forms.Label();
            this.patweightlb = new System.Windows.Forms.Label();
            this.patheightlb = new System.Windows.Forms.Label();
            this.patgenderlb = new System.Windows.Forms.Label();
            this.patagelb = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Diseaselb = new System.Windows.Forms.Label();
            this.patnamelb = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aptpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TreatDGV)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 11.8F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(66, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 44);
            this.label4.TabIndex = 8;
            this.label4.Text = "Appoinmnet\r\n        list";
            // 
            // Doctorlb
            // 
            this.Doctorlb.AutoSize = true;
            this.Doctorlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Doctorlb.ForeColor = System.Drawing.Color.White;
            this.Doctorlb.Location = new System.Drawing.Point(46, 132);
            this.Doctorlb.Name = "Doctorlb";
            this.Doctorlb.Size = new System.Drawing.Size(83, 25);
            this.Doctorlb.TabIndex = 4;
            this.Doctorlb.Text = "Doctor";
            this.Doctorlb.Click += new System.EventHandler(this.Doctorlb_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Logoutpicbox);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Aptpicbox);
            this.panel1.Controls.Add(this.Doctorlb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(195, 699);
            this.panel1.TabIndex = 200;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Teal;
            this.pictureBox4.Image = global::HMA.Properties.Resources.L;
            this.pictureBox4.Location = new System.Drawing.Point(39, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(101, 101);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(75, 628);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "Logout";
            // 
            // Logoutpicbox
            // 
            this.Logoutpicbox.Image = global::HMA.Properties.Resources.logout;
            this.Logoutpicbox.Location = new System.Drawing.Point(21, 606);
            this.Logoutpicbox.Name = "Logoutpicbox";
            this.Logoutpicbox.Size = new System.Drawing.Size(48, 67);
            this.Logoutpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logoutpicbox.TabIndex = 13;
            this.Logoutpicbox.TabStop = false;
            this.Logoutpicbox.Click += new System.EventHandler(this.Logoutpicbox_Click);
            // 
            // Aptpicbox
            // 
            this.Aptpicbox.Image = global::HMA.Properties.Resources.files;
            this.Aptpicbox.Location = new System.Drawing.Point(12, 313);
            this.Aptpicbox.Name = "Aptpicbox";
            this.Aptpicbox.Size = new System.Drawing.Size(48, 74);
            this.Aptpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Aptpicbox.TabIndex = 7;
            this.Aptpicbox.TabStop = false;
            this.Aptpicbox.Click += new System.EventHandler(this.Aptpicbox_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lime;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Image = global::HMA.Properties.Resources.v870_tang_36;
            this.pictureBox2.Location = new System.Drawing.Point(192, -24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(994, 723);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 188;
            this.pictureBox2.TabStop = false;
            // 
            // TreatDGV
            // 
            this.TreatDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TreatDGV.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.TreatDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TreatDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TreatDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.TreatDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TreatDGV.EnableHeadersVisualStyles = false;
            this.TreatDGV.GridColor = System.Drawing.Color.MidnightBlue;
            this.TreatDGV.Location = new System.Drawing.Point(315, 333);
            this.TreatDGV.Name = "TreatDGV";
            this.TreatDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.TreatDGV.RowHeadersVisible = false;
            this.TreatDGV.RowHeadersWidth = 51;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Ivory;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.TreatDGV.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.TreatDGV.RowTemplate.Height = 24;
            this.TreatDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TreatDGV.Size = new System.Drawing.Size(787, 340);
            this.TreatDGV.TabIndex = 204;
            this.TreatDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TreatDGV_CellContentClick);
            // 
            // PrevrecordBtn
            // 
            this.PrevrecordBtn.BackColor = System.Drawing.Color.Transparent;
            this.PrevrecordBtn.FlatAppearance.BorderSize = 2;
            this.PrevrecordBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PrevrecordBtn.Font = new System.Drawing.Font("Bahnschrift", 12.2F, System.Drawing.FontStyle.Bold);
            this.PrevrecordBtn.ForeColor = System.Drawing.Color.Black;
            this.PrevrecordBtn.Location = new System.Drawing.Point(710, 132);
            this.PrevrecordBtn.Name = "PrevrecordBtn";
            this.PrevrecordBtn.Size = new System.Drawing.Size(187, 45);
            this.PrevrecordBtn.TabIndex = 206;
            this.PrevrecordBtn.Text = "Previous records";
            this.PrevrecordBtn.UseVisualStyleBackColor = false;
            this.PrevrecordBtn.Click += new System.EventHandler(this.PrevrecordBtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.DoneBtn);
            this.panel2.Controls.Add(this.GiveTrttxt);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.patBgrplb);
            this.panel2.Controls.Add(this.PrevrecordBtn);
            this.panel2.Controls.Add(this.patweightlb);
            this.panel2.Controls.Add(this.patheightlb);
            this.panel2.Controls.Add(this.patgenderlb);
            this.panel2.Controls.Add(this.patagelb);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.Diseaselb);
            this.panel2.Controls.Add(this.patnamelb);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(192, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(980, 299);
            this.panel2.TabIndex = 213;
            // 
            // DoneBtn
            // 
            this.DoneBtn.BackColor = System.Drawing.Color.Teal;
            this.DoneBtn.FlatAppearance.BorderSize = 2;
            this.DoneBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DoneBtn.Font = new System.Drawing.Font("Bahnschrift", 12.2F, System.Drawing.FontStyle.Bold);
            this.DoneBtn.ForeColor = System.Drawing.Color.White;
            this.DoneBtn.Location = new System.Drawing.Point(873, 217);
            this.DoneBtn.Name = "DoneBtn";
            this.DoneBtn.Size = new System.Drawing.Size(87, 38);
            this.DoneBtn.TabIndex = 229;
            this.DoneBtn.Text = "Done";
            this.DoneBtn.UseVisualStyleBackColor = false;
            this.DoneBtn.Click += new System.EventHandler(this.DoneBtn_Click);
            // 
            // GiveTrttxt
            // 
            this.GiveTrttxt.BackColor = System.Drawing.Color.White;
            this.GiveTrttxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GiveTrttxt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GiveTrttxt.ForeColor = System.Drawing.Color.Black;
            this.GiveTrttxt.Location = new System.Drawing.Point(217, 194);
            this.GiveTrttxt.Multiline = true;
            this.GiveTrttxt.Name = "GiveTrttxt";
            this.GiveTrttxt.Size = new System.Drawing.Size(650, 87);
            this.GiveTrttxt.TabIndex = 228;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(24, 194);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(187, 29);
            this.label10.TabIndex = 227;
            this.label10.Text = "Give Treatment :";
            // 
            // patBgrplb
            // 
            this.patBgrplb.AutoSize = true;
            this.patBgrplb.BackColor = System.Drawing.Color.Transparent;
            this.patBgrplb.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patBgrplb.Location = new System.Drawing.Point(796, 95);
            this.patBgrplb.Name = "patBgrplb";
            this.patBgrplb.Size = new System.Drawing.Size(0, 29);
            this.patBgrplb.TabIndex = 226;
            // 
            // patweightlb
            // 
            this.patweightlb.AutoSize = true;
            this.patweightlb.BackColor = System.Drawing.Color.Transparent;
            this.patweightlb.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patweightlb.Location = new System.Drawing.Point(796, 48);
            this.patweightlb.Name = "patweightlb";
            this.patweightlb.Size = new System.Drawing.Size(0, 29);
            this.patweightlb.TabIndex = 225;
            // 
            // patheightlb
            // 
            this.patheightlb.AutoSize = true;
            this.patheightlb.BackColor = System.Drawing.Color.Transparent;
            this.patheightlb.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patheightlb.Location = new System.Drawing.Point(533, 48);
            this.patheightlb.Name = "patheightlb";
            this.patheightlb.Size = new System.Drawing.Size(0, 29);
            this.patheightlb.TabIndex = 224;
            // 
            // patgenderlb
            // 
            this.patgenderlb.AutoSize = true;
            this.patgenderlb.BackColor = System.Drawing.Color.Transparent;
            this.patgenderlb.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patgenderlb.Location = new System.Drawing.Point(296, 48);
            this.patgenderlb.Name = "patgenderlb";
            this.patgenderlb.Size = new System.Drawing.Size(0, 29);
            this.patgenderlb.TabIndex = 223;
            // 
            // patagelb
            // 
            this.patagelb.AutoSize = true;
            this.patagelb.BackColor = System.Drawing.Color.Transparent;
            this.patagelb.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patagelb.Location = new System.Drawing.Point(85, 48);
            this.patagelb.Name = "patagelb";
            this.patagelb.Size = new System.Drawing.Size(0, 29);
            this.patagelb.TabIndex = 222;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(639, 95);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(151, 29);
            this.label12.TabIndex = 221;
            this.label12.Text = "Blood Group:";
            // 
            // Diseaselb
            // 
            this.Diseaselb.BackColor = System.Drawing.Color.Transparent;
            this.Diseaselb.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Diseaselb.Location = new System.Drawing.Point(223, 95);
            this.Diseaselb.Name = "Diseaselb";
            this.Diseaselb.Size = new System.Drawing.Size(316, 82);
            this.Diseaselb.TabIndex = 220;
            // 
            // patnamelb
            // 
            this.patnamelb.AutoSize = true;
            this.patnamelb.BackColor = System.Drawing.Color.Transparent;
            this.patnamelb.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patnamelb.Location = new System.Drawing.Point(198, 9);
            this.patnamelb.Name = "patnamelb";
            this.patnamelb.Size = new System.Drawing.Size(0, 29);
            this.patnamelb.TabIndex = 219;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(193, 29);
            this.label9.TabIndex = 218;
            this.label9.Text = "Current Diseases :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(436, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 29);
            this.label8.TabIndex = 217;
            this.label8.Text = "Height:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(696, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 29);
            this.label6.TabIndex = 216;
            this.label6.Text = "Weight:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(198, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 29);
            this.label5.TabIndex = 215;
            this.label5.Text = "Gender:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 29);
            this.label3.TabIndex = 214;
            this.label3.Text = "Age :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 29);
            this.label1.TabIndex = 213;
            this.label1.Text = "Patient Name :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Bisque;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(612, 307);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 23);
            this.label11.TabIndex = 230;
            this.label11.Text = "Patient List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(602, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 29);
            this.label2.TabIndex = 230;
            this.label2.Text = "Cm";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(850, 48);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 29);
            this.label13.TabIndex = 231;
            this.label13.Text = "Kg";
            // 
            // TreatmentUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1176, 699);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.TreatDGV);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TreatmentUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TreatmentUI";
            this.Load += new System.EventHandler(this.TreatmentUI_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aptpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TreatDGV)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Doctorlb;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox Logoutpicbox;
        private System.Windows.Forms.PictureBox Aptpicbox;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView TreatDGV;
        private System.Windows.Forms.Button PrevrecordBtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label patBgrplb;
        private System.Windows.Forms.Label patweightlb;
        private System.Windows.Forms.Label patheightlb;
        private System.Windows.Forms.Label patgenderlb;
        private System.Windows.Forms.Label patagelb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Diseaselb;
        private System.Windows.Forms.Label patnamelb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DoneBtn;
        private System.Windows.Forms.TextBox GiveTrttxt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label2;
    }
}