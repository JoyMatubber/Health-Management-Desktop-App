﻿
namespace HMA
{
    partial class PatientMedicalHistory_UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.SeeAptpicbox = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Logoutpicbox = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BloodBankpicbox = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.DiseasePredpicbox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BookAptpicbox = new System.Windows.Forms.PictureBox();
            this.Patientlb = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.HistoryDGV = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BloodBankpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiseasePredpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAptpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HistoryDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.SeeAptpicbox);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Logoutpicbox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.BloodBankpicbox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.DiseasePredpicbox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.BookAptpicbox);
            this.panel1.Controls.Add(this.Patientlb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 775);
            this.panel1.TabIndex = 48;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(64, 307);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 44);
            this.label12.TabIndex = 26;
            this.label12.Text = "See \r\nAppoinment";
            // 
            // SeeAptpicbox
            // 
            this.SeeAptpicbox.Image = global::HMA.Properties.Resources.appointment;
            this.SeeAptpicbox.Location = new System.Drawing.Point(16, 307);
            this.SeeAptpicbox.Name = "SeeAptpicbox";
            this.SeeAptpicbox.Size = new System.Drawing.Size(42, 56);
            this.SeeAptpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SeeAptpicbox.TabIndex = 25;
            this.SeeAptpicbox.TabStop = false;
            this.SeeAptpicbox.Click += new System.EventHandler(this.SeeAptpicbox_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Teal;
            this.pictureBox4.Image = global::HMA.Properties.Resources.L;
            this.pictureBox4.Location = new System.Drawing.Point(12, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(101, 101);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(67, 600);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 24);
            this.label7.TabIndex = 14;
            this.label7.Text = "Logout";
            // 
            // Logoutpicbox
            // 
            this.Logoutpicbox.Image = global::HMA.Properties.Resources.logout;
            this.Logoutpicbox.Location = new System.Drawing.Point(19, 584);
            this.Logoutpicbox.Name = "Logoutpicbox";
            this.Logoutpicbox.Size = new System.Drawing.Size(42, 56);
            this.Logoutpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logoutpicbox.TabIndex = 13;
            this.Logoutpicbox.TabStop = false;
            this.Logoutpicbox.Click += new System.EventHandler(this.Logoutpicbox_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(64, 514);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 24);
            this.label6.TabIndex = 12;
            this.label6.Text = "Blood Bank";
            // 
            // BloodBankpicbox
            // 
            this.BloodBankpicbox.Image = global::HMA.Properties.Resources.blood_bank;
            this.BloodBankpicbox.Location = new System.Drawing.Point(16, 489);
            this.BloodBankpicbox.Name = "BloodBankpicbox";
            this.BloodBankpicbox.Size = new System.Drawing.Size(42, 56);
            this.BloodBankpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BloodBankpicbox.TabIndex = 11;
            this.BloodBankpicbox.TabStop = false;
            this.BloodBankpicbox.Click += new System.EventHandler(this.BloodBankpicbox_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(67, 406);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 48);
            this.label5.TabIndex = 10;
            this.label5.Text = "Predict \r\nDisease";
            // 
            // DiseasePredpicbox
            // 
            this.DiseasePredpicbox.Image = global::HMA.Properties.Resources.disease;
            this.DiseasePredpicbox.Location = new System.Drawing.Point(19, 398);
            this.DiseasePredpicbox.Name = "DiseasePredpicbox";
            this.DiseasePredpicbox.Size = new System.Drawing.Size(42, 56);
            this.DiseasePredpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.DiseasePredpicbox.TabIndex = 9;
            this.DiseasePredpicbox.TabStop = false;
            this.DiseasePredpicbox.Click += new System.EventHandler(this.DiseasePredpicbox_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(64, 236);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 44);
            this.label3.TabIndex = 6;
            this.label3.Text = "Book \r\nAppointment";
            // 
            // BookAptpicbox
            // 
            this.BookAptpicbox.Image = global::HMA.Properties.Resources.appointment_book;
            this.BookAptpicbox.Location = new System.Drawing.Point(16, 236);
            this.BookAptpicbox.Name = "BookAptpicbox";
            this.BookAptpicbox.Size = new System.Drawing.Size(42, 56);
            this.BookAptpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BookAptpicbox.TabIndex = 5;
            this.BookAptpicbox.TabStop = false;
            this.BookAptpicbox.Click += new System.EventHandler(this.BookAptpicbox_Click);
            // 
            // Patientlb
            // 
            this.Patientlb.AutoSize = true;
            this.Patientlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Patientlb.ForeColor = System.Drawing.Color.White;
            this.Patientlb.Location = new System.Drawing.Point(14, 122);
            this.Patientlb.Name = "Patientlb";
            this.Patientlb.Size = new System.Drawing.Size(99, 25);
            this.Patientlb.TabIndex = 4;
            this.Patientlb.Text = "Patient ";
            this.Patientlb.Click += new System.EventHandler(this.Patientlb_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lime;
            this.pictureBox2.Image = global::HMA.Properties.Resources.v870_tang_36;
            this.pictureBox2.Location = new System.Drawing.Point(72, -9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1212, 784);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // HistoryDGV
            // 
            this.HistoryDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.HistoryDGV.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.HistoryDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HistoryDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.HistoryDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.HistoryDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HistoryDGV.EnableHeadersVisualStyles = false;
            this.HistoryDGV.GridColor = System.Drawing.Color.MidnightBlue;
            this.HistoryDGV.Location = new System.Drawing.Point(265, 195);
            this.HistoryDGV.Name = "HistoryDGV";
            this.HistoryDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.HistoryDGV.RowHeadersVisible = false;
            this.HistoryDGV.RowHeadersWidth = 51;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.HistoryDGV.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.HistoryDGV.RowTemplate.Height = 24;
            this.HistoryDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.HistoryDGV.Size = new System.Drawing.Size(867, 410);
            this.HistoryDGV.TabIndex = 204;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 15F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(589, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 26);
            this.label1.TabIndex = 27;
            this.label1.Text = "Previous History";
            // 
            // PatientMedicalHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 775);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HistoryDGV);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PatientMedicalHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PatientMedicalHistory";
            this.Load += new System.EventHandler(this.PatientMedicalHistory_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BloodBankpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiseasePredpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAptpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HistoryDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox SeeAptpicbox;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox Logoutpicbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox BloodBankpicbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox DiseasePredpicbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox BookAptpicbox;
        private System.Windows.Forms.Label Patientlb;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView HistoryDGV;
        private System.Windows.Forms.Label label1;
    }
}