﻿
namespace HMA
{
    partial class ViewAppointment_UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Logoutpicbox = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BloodBankpicbox = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.DiseasePredpicbox = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MedHistorypicbox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BookAPtpicbox = new System.Windows.Forms.PictureBox();
            this.Patientlb = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.UpAptDgv = new System.Windows.Forms.DataGridView();
            this.PrevAptDgv = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.dltlb = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BloodBankpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiseasePredpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MedHistorypicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAPtpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UpAptDgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrevAptDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Logoutpicbox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.BloodBankpicbox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.DiseasePredpicbox);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.MedHistorypicbox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.BookAPtpicbox);
            this.panel1.Controls.Add(this.Patientlb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(214, 789);
            this.panel1.TabIndex = 48;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Teal;
            this.pictureBox4.Image = global::HMA.Properties.Resources.L;
            this.pictureBox4.Location = new System.Drawing.Point(12, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(101, 101);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(67, 621);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 24);
            this.label7.TabIndex = 14;
            this.label7.Text = "Logout";
            // 
            // Logoutpicbox
            // 
            this.Logoutpicbox.Image = global::HMA.Properties.Resources.logout;
            this.Logoutpicbox.Location = new System.Drawing.Point(19, 605);
            this.Logoutpicbox.Name = "Logoutpicbox";
            this.Logoutpicbox.Size = new System.Drawing.Size(42, 56);
            this.Logoutpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logoutpicbox.TabIndex = 13;
            this.Logoutpicbox.TabStop = false;
            this.Logoutpicbox.Click += new System.EventHandler(this.Logoutpicbox_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(64, 535);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 24);
            this.label6.TabIndex = 12;
            this.label6.Text = "Blood Bank";
            // 
            // BloodBankpicbox
            // 
            this.BloodBankpicbox.Image = global::HMA.Properties.Resources.blood_bank;
            this.BloodBankpicbox.Location = new System.Drawing.Point(16, 510);
            this.BloodBankpicbox.Name = "BloodBankpicbox";
            this.BloodBankpicbox.Size = new System.Drawing.Size(42, 56);
            this.BloodBankpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BloodBankpicbox.TabIndex = 11;
            this.BloodBankpicbox.TabStop = false;
            this.BloodBankpicbox.Click += new System.EventHandler(this.BloodBankpicbox_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(67, 427);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 48);
            this.label5.TabIndex = 10;
            this.label5.Text = "Predict \r\nDisease";
            // 
            // DiseasePredpicbox
            // 
            this.DiseasePredpicbox.Image = global::HMA.Properties.Resources.disease;
            this.DiseasePredpicbox.Location = new System.Drawing.Point(19, 419);
            this.DiseasePredpicbox.Name = "DiseasePredpicbox";
            this.DiseasePredpicbox.Size = new System.Drawing.Size(42, 56);
            this.DiseasePredpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.DiseasePredpicbox.TabIndex = 9;
            this.DiseasePredpicbox.TabStop = false;
            this.DiseasePredpicbox.Click += new System.EventHandler(this.DiseasePredpicbox_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(67, 331);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 48);
            this.label4.TabIndex = 8;
            this.label4.Text = "Medical \r\n History";
            // 
            // MedHistorypicbox
            // 
            this.MedHistorypicbox.Image = global::HMA.Properties.Resources.medical_history;
            this.MedHistorypicbox.Location = new System.Drawing.Point(19, 325);
            this.MedHistorypicbox.Name = "MedHistorypicbox";
            this.MedHistorypicbox.Size = new System.Drawing.Size(42, 56);
            this.MedHistorypicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.MedHistorypicbox.TabIndex = 7;
            this.MedHistorypicbox.TabStop = false;
            this.MedHistorypicbox.Click += new System.EventHandler(this.MedHistorypicbox_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(70, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 44);
            this.label3.TabIndex = 6;
            this.label3.Text = "Book \r\nAppointment";
            // 
            // BookAPtpicbox
            // 
            this.BookAPtpicbox.Image = global::HMA.Properties.Resources.appointment_book;
            this.BookAPtpicbox.Location = new System.Drawing.Point(19, 229);
            this.BookAPtpicbox.Name = "BookAPtpicbox";
            this.BookAPtpicbox.Size = new System.Drawing.Size(42, 56);
            this.BookAPtpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BookAPtpicbox.TabIndex = 5;
            this.BookAPtpicbox.TabStop = false;
            this.BookAPtpicbox.Click += new System.EventHandler(this.BookAPtpicbox_Click);
            // 
            // Patientlb
            // 
            this.Patientlb.AutoSize = true;
            this.Patientlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Patientlb.ForeColor = System.Drawing.Color.White;
            this.Patientlb.Location = new System.Drawing.Point(14, 122);
            this.Patientlb.Name = "Patientlb";
            this.Patientlb.Size = new System.Drawing.Size(99, 25);
            this.Patientlb.TabIndex = 4;
            this.Patientlb.Text = "Patient ";
            this.Patientlb.Click += new System.EventHandler(this.Patientlb_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lime;
            this.pictureBox2.Image = global::HMA.Properties.Resources.v870_tang_36;
            this.pictureBox2.Location = new System.Drawing.Point(97, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1118, 791);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // UpAptDgv
            // 
            this.UpAptDgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.UpAptDgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.UpAptDgv.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.UpAptDgv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.UpAptDgv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Cambria", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.UpAptDgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.UpAptDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UpAptDgv.EnableHeadersVisualStyles = false;
            this.UpAptDgv.GridColor = System.Drawing.Color.MidnightBlue;
            this.UpAptDgv.Location = new System.Drawing.Point(278, 113);
            this.UpAptDgv.Name = "UpAptDgv";
            this.UpAptDgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.UpAptDgv.RowHeadersVisible = false;
            this.UpAptDgv.RowHeadersWidth = 51;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Times New Roman", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.White;
            this.UpAptDgv.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.UpAptDgv.RowTemplate.Height = 24;
            this.UpAptDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.UpAptDgv.Size = new System.Drawing.Size(867, 236);
            this.UpAptDgv.TabIndex = 204;
            this.UpAptDgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.UpAptDgv_CellContentClick);
            // 
            // PrevAptDgv
            // 
            this.PrevAptDgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PrevAptDgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.PrevAptDgv.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.PrevAptDgv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PrevAptDgv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Cambria", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PrevAptDgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.PrevAptDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PrevAptDgv.EnableHeadersVisualStyles = false;
            this.PrevAptDgv.GridColor = System.Drawing.Color.MidnightBlue;
            this.PrevAptDgv.Location = new System.Drawing.Point(278, 495);
            this.PrevAptDgv.Name = "PrevAptDgv";
            this.PrevAptDgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.PrevAptDgv.RowHeadersVisible = false;
            this.PrevAptDgv.RowHeadersWidth = 51;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Times New Roman", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.White;
            this.PrevAptDgv.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.PrevAptDgv.RowTemplate.Height = 24;
            this.PrevAptDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PrevAptDgv.Size = new System.Drawing.Size(867, 236);
            this.PrevAptDgv.TabIndex = 205;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(608, 67);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(216, 23);
            this.label12.TabIndex = 212;
            this.label12.Text = "Upcoming Appointments";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(639, 452);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 23);
            this.label1.TabIndex = 213;
            this.label1.Text = "Previous Appoinments";
            // 
            // Deletebtn
            // 
            this.Deletebtn.BackColor = System.Drawing.Color.Teal;
            this.Deletebtn.FlatAppearance.BorderSize = 2;
            this.Deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletebtn.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebtn.ForeColor = System.Drawing.Color.White;
            this.Deletebtn.Location = new System.Drawing.Point(975, 355);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(170, 48);
            this.Deletebtn.TabIndex = 214;
            this.Deletebtn.Text = "Delete";
            this.Deletebtn.UseVisualStyleBackColor = false;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // dltlb
            // 
            this.dltlb.AutoSize = true;
            this.dltlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dltlb.ForeColor = System.Drawing.Color.White;
            this.dltlb.Location = new System.Drawing.Point(1097, 85);
            this.dltlb.Name = "dltlb";
            this.dltlb.Size = new System.Drawing.Size(48, 25);
            this.dltlb.TabIndex = 25;
            this.dltlb.Text = "See";
            this.dltlb.Visible = false;
            // 
            // ViewAppointment_UI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 789);
            this.Controls.Add(this.Deletebtn);
            this.Controls.Add(this.dltlb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.PrevAptDgv);
            this.Controls.Add(this.UpAptDgv);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ViewAppointment_UI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewAppointment_UI";
            this.Load += new System.EventHandler(this.ViewAppointment_UI_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BloodBankpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiseasePredpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MedHistorypicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAPtpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UpAptDgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrevAptDgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox Logoutpicbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox BloodBankpicbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox DiseasePredpicbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox MedHistorypicbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox BookAPtpicbox;
        private System.Windows.Forms.Label Patientlb;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView UpAptDgv;
        private System.Windows.Forms.DataGridView PrevAptDgv;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Deletebtn;
        private System.Windows.Forms.Label dltlb;
    }
}