﻿
namespace HMA
{
    partial class BloodBankUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Ptcrndis = new System.Windows.Forms.Label();
            this.Ptage = new System.Windows.Forms.Label();
            this.Ptphone = new System.Windows.Forms.Label();
            this.Ptname = new System.Windows.Forms.Label();
            this.Ptbgrp = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.SeeAptpicbox = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Logoutpicbox = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.DiseasePredpicbox = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MedlHistorypicbox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BookAptpicbox = new System.Windows.Forms.PictureBox();
            this.Patientlb = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.DonorLitsDGV = new System.Windows.Forms.DataGridView();
            this.SeacrhBtn = new System.Windows.Forms.Button();
            this.searchtxt = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel11 = new System.Windows.Forms.FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiseasePredpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MedlHistorypicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAptpicbox)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DonorLitsDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // Ptcrndis
            // 
            this.Ptcrndis.AutoSize = true;
            this.Ptcrndis.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Ptcrndis.Location = new System.Drawing.Point(373, 307);
            this.Ptcrndis.Name = "Ptcrndis";
            this.Ptcrndis.Size = new System.Drawing.Size(0, 28);
            this.Ptcrndis.TabIndex = 58;
            // 
            // Ptage
            // 
            this.Ptage.AutoSize = true;
            this.Ptage.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Ptage.Location = new System.Drawing.Point(373, 169);
            this.Ptage.Name = "Ptage";
            this.Ptage.Size = new System.Drawing.Size(0, 28);
            this.Ptage.TabIndex = 56;
            // 
            // Ptphone
            // 
            this.Ptphone.AutoSize = true;
            this.Ptphone.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Ptphone.Location = new System.Drawing.Point(373, 120);
            this.Ptphone.Name = "Ptphone";
            this.Ptphone.Size = new System.Drawing.Size(0, 28);
            this.Ptphone.TabIndex = 55;
            // 
            // Ptname
            // 
            this.Ptname.AutoSize = true;
            this.Ptname.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Ptname.Location = new System.Drawing.Point(373, 59);
            this.Ptname.Name = "Ptname";
            this.Ptname.Size = new System.Drawing.Size(0, 28);
            this.Ptname.TabIndex = 54;
            // 
            // Ptbgrp
            // 
            this.Ptbgrp.AutoSize = true;
            this.Ptbgrp.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Ptbgrp.Location = new System.Drawing.Point(373, 235);
            this.Ptbgrp.Name = "Ptbgrp";
            this.Ptbgrp.Size = new System.Drawing.Size(0, 28);
            this.Ptbgrp.TabIndex = 57;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(267, -143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 89);
            this.label1.TabIndex = 47;
            this.label1.Text = "Welcome !";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lime;
            this.pictureBox2.Image = global::HMA.Properties.Resources.v870_tang_36;
            this.pictureBox2.Location = new System.Drawing.Point(183, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1695, 789);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.SeeAptpicbox);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Logoutpicbox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.DiseasePredpicbox);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.MedlHistorypicbox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.BookAptpicbox);
            this.panel1.Controls.Add(this.Patientlb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(199, 789);
            this.panel1.TabIndex = 59;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(60, 303);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 44);
            this.label12.TabIndex = 28;
            this.label12.Text = "See \r\nAppoinment";
            // 
            // SeeAptpicbox
            // 
            this.SeeAptpicbox.Image = global::HMA.Properties.Resources.appointment;
            this.SeeAptpicbox.Location = new System.Drawing.Point(12, 291);
            this.SeeAptpicbox.Name = "SeeAptpicbox";
            this.SeeAptpicbox.Size = new System.Drawing.Size(42, 56);
            this.SeeAptpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SeeAptpicbox.TabIndex = 27;
            this.SeeAptpicbox.TabStop = false;
            this.SeeAptpicbox.Click += new System.EventHandler(this.SeeAptpicbox_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Teal;
            this.pictureBox4.Image = global::HMA.Properties.Resources.L;
            this.pictureBox4.Location = new System.Drawing.Point(12, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(101, 101);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(70, 580);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 24);
            this.label7.TabIndex = 14;
            this.label7.Text = "Logout";
            // 
            // Logoutpicbox
            // 
            this.Logoutpicbox.Image = global::HMA.Properties.Resources.logout;
            this.Logoutpicbox.Location = new System.Drawing.Point(12, 565);
            this.Logoutpicbox.Name = "Logoutpicbox";
            this.Logoutpicbox.Size = new System.Drawing.Size(42, 56);
            this.Logoutpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logoutpicbox.TabIndex = 13;
            this.Logoutpicbox.TabStop = false;
            this.Logoutpicbox.Click += new System.EventHandler(this.Logoutpicbox_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(60, 469);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 48);
            this.label5.TabIndex = 10;
            this.label5.Text = "Predict \r\nDisease";
            // 
            // DiseasePredpicbox
            // 
            this.DiseasePredpicbox.Image = global::HMA.Properties.Resources.disease;
            this.DiseasePredpicbox.Location = new System.Drawing.Point(12, 461);
            this.DiseasePredpicbox.Name = "DiseasePredpicbox";
            this.DiseasePredpicbox.Size = new System.Drawing.Size(42, 56);
            this.DiseasePredpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.DiseasePredpicbox.TabIndex = 9;
            this.DiseasePredpicbox.TabStop = false;
            this.DiseasePredpicbox.Click += new System.EventHandler(this.DiseasePredpicbox_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 13F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(60, 373);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 48);
            this.label4.TabIndex = 8;
            this.label4.Text = "Medical \r\n History";
            // 
            // MedlHistorypicbox
            // 
            this.MedlHistorypicbox.Image = global::HMA.Properties.Resources.medical_history;
            this.MedlHistorypicbox.Location = new System.Drawing.Point(12, 367);
            this.MedlHistorypicbox.Name = "MedlHistorypicbox";
            this.MedlHistorypicbox.Size = new System.Drawing.Size(42, 56);
            this.MedlHistorypicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.MedlHistorypicbox.TabIndex = 7;
            this.MedlHistorypicbox.TabStop = false;
            this.MedlHistorypicbox.Click += new System.EventHandler(this.MedlHistorypicbox_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(60, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 44);
            this.label3.TabIndex = 6;
            this.label3.Text = "Book \r\nAppointment";
            // 
            // BookAptpicbox
            // 
            this.BookAptpicbox.Image = global::HMA.Properties.Resources.appointment_book;
            this.BookAptpicbox.Location = new System.Drawing.Point(12, 219);
            this.BookAptpicbox.Name = "BookAptpicbox";
            this.BookAptpicbox.Size = new System.Drawing.Size(42, 56);
            this.BookAptpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BookAptpicbox.TabIndex = 5;
            this.BookAptpicbox.TabStop = false;
            this.BookAptpicbox.Click += new System.EventHandler(this.BookAptpicbox_Click);
            // 
            // Patientlb
            // 
            this.Patientlb.AutoSize = true;
            this.Patientlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Patientlb.ForeColor = System.Drawing.Color.White;
            this.Patientlb.Location = new System.Drawing.Point(25, 120);
            this.Patientlb.Name = "Patientlb";
            this.Patientlb.Size = new System.Drawing.Size(99, 25);
            this.Patientlb.TabIndex = 4;
            this.Patientlb.Text = "Patient ";
            this.Patientlb.Click += new System.EventHandler(this.Patientlb_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(199, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1014, 100);
            this.panel2.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 36.8F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(390, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(342, 63);
            this.label6.TabIndex = 25;
            this.label6.Text = "Blood Bank";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::HMA.Properties.Resources.blood_bank1;
            this.pictureBox5.Location = new System.Drawing.Point(249, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(135, 75);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // DonorLitsDGV
            // 
            this.DonorLitsDGV.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DonorLitsDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DonorLitsDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DonorLitsDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DonorLitsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DonorLitsDGV.EnableHeadersVisualStyles = false;
            this.DonorLitsDGV.GridColor = System.Drawing.Color.MidnightBlue;
            this.DonorLitsDGV.Location = new System.Drawing.Point(309, 200);
            this.DonorLitsDGV.Name = "DonorLitsDGV";
            this.DonorLitsDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DonorLitsDGV.RowHeadersVisible = false;
            this.DonorLitsDGV.RowHeadersWidth = 51;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            this.DonorLitsDGV.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DonorLitsDGV.RowTemplate.Height = 24;
            this.DonorLitsDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DonorLitsDGV.Size = new System.Drawing.Size(843, 514);
            this.DonorLitsDGV.TabIndex = 186;
            // 
            // SeacrhBtn
            // 
            this.SeacrhBtn.BackColor = System.Drawing.Color.Teal;
            this.SeacrhBtn.FlatAppearance.BorderSize = 2;
            this.SeacrhBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SeacrhBtn.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeacrhBtn.ForeColor = System.Drawing.Color.White;
            this.SeacrhBtn.Location = new System.Drawing.Point(469, 120);
            this.SeacrhBtn.Name = "SeacrhBtn";
            this.SeacrhBtn.Size = new System.Drawing.Size(225, 48);
            this.SeacrhBtn.TabIndex = 214;
            this.SeacrhBtn.Text = "Search Group";
            this.SeacrhBtn.UseVisualStyleBackColor = false;
            this.SeacrhBtn.Click += new System.EventHandler(this.SeacrhBtn_Click);
            // 
            // searchtxt
            // 
            this.searchtxt.BackColor = System.Drawing.Color.White;
            this.searchtxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.searchtxt.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold);
            this.searchtxt.ForeColor = System.Drawing.Color.Black;
            this.searchtxt.Location = new System.Drawing.Point(708, 128);
            this.searchtxt.Name = "searchtxt";
            this.searchtxt.Size = new System.Drawing.Size(273, 33);
            this.searchtxt.TabIndex = 216;
            // 
            // flowLayoutPanel11
            // 
            this.flowLayoutPanel11.BackColor = System.Drawing.Color.Teal;
            this.flowLayoutPanel11.Location = new System.Drawing.Point(708, 168);
            this.flowLayoutPanel11.Name = "flowLayoutPanel11";
            this.flowLayoutPanel11.Size = new System.Drawing.Size(290, 1);
            this.flowLayoutPanel11.TabIndex = 215;
            // 
            // BloodBankUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 789);
            this.Controls.Add(this.SeacrhBtn);
            this.Controls.Add(this.searchtxt);
            this.Controls.Add(this.DonorLitsDGV);
            this.Controls.Add(this.flowLayoutPanel11);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Ptcrndis);
            this.Controls.Add(this.Ptage);
            this.Controls.Add(this.Ptphone);
            this.Controls.Add(this.Ptname);
            this.Controls.Add(this.Ptbgrp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BloodBankUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BloodBankUI";
            this.Load += new System.EventHandler(this.BloodBankUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiseasePredpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MedlHistorypicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookAptpicbox)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DonorLitsDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Ptcrndis;
        private System.Windows.Forms.Label Ptage;
        private System.Windows.Forms.Label Ptphone;
        private System.Windows.Forms.Label Ptname;
        private System.Windows.Forms.Label Ptbgrp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox Logoutpicbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox DiseasePredpicbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox MedlHistorypicbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox BookAptpicbox;
        private System.Windows.Forms.Label Patientlb;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView DonorLitsDGV;
        private System.Windows.Forms.Button SeacrhBtn;
        private System.Windows.Forms.TextBox searchtxt;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox SeeAptpicbox;
    }
}