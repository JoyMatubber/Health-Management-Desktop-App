﻿
namespace HMA
{
    partial class Doctor_UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Drhcham = new System.Windows.Forms.Label();
            this.Drvhrs = new System.Windows.Forms.Label();
            this.Drvdays = new System.Windows.Forms.Label();
            this.Drdpt = new System.Windows.Forms.Label();
            this.Drname = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Logoutpicbox = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Givetreatmentpicbox = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Aptlistpicbox = new System.Windows.Forms.PictureBox();
            this.Doctorlb = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Givetreatmentpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aptlistpicbox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.AliceBlue;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(474, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 89);
            this.label1.TabIndex = 44;
            this.label1.Text = "Welcome !";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lime;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Image = global::HMA.Properties.Resources.v870_tang_36;
            this.pictureBox2.Location = new System.Drawing.Point(201, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(994, 746);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 43;
            this.pictureBox2.TabStop = false;
            // 
            // Drhcham
            // 
            this.Drhcham.AutoSize = true;
            this.Drhcham.BackColor = System.Drawing.Color.Transparent;
            this.Drhcham.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drhcham.ForeColor = System.Drawing.Color.Teal;
            this.Drhcham.Location = new System.Drawing.Point(694, 487);
            this.Drhcham.Name = "Drhcham";
            this.Drhcham.Size = new System.Drawing.Size(0, 29);
            this.Drhcham.TabIndex = 183;
            // 
            // Drvhrs
            // 
            this.Drvhrs.AutoSize = true;
            this.Drvhrs.BackColor = System.Drawing.Color.Transparent;
            this.Drvhrs.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drvhrs.ForeColor = System.Drawing.Color.Teal;
            this.Drvhrs.Location = new System.Drawing.Point(694, 422);
            this.Drvhrs.Name = "Drvhrs";
            this.Drvhrs.Size = new System.Drawing.Size(0, 29);
            this.Drvhrs.TabIndex = 182;
            // 
            // Drvdays
            // 
            this.Drvdays.AutoSize = true;
            this.Drvdays.BackColor = System.Drawing.Color.Transparent;
            this.Drvdays.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drvdays.ForeColor = System.Drawing.Color.Teal;
            this.Drvdays.Location = new System.Drawing.Point(692, 357);
            this.Drvdays.Name = "Drvdays";
            this.Drvdays.Size = new System.Drawing.Size(0, 29);
            this.Drvdays.TabIndex = 181;
            // 
            // Drdpt
            // 
            this.Drdpt.AutoSize = true;
            this.Drdpt.BackColor = System.Drawing.Color.Transparent;
            this.Drdpt.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drdpt.ForeColor = System.Drawing.Color.Teal;
            this.Drdpt.Location = new System.Drawing.Point(694, 288);
            this.Drdpt.Name = "Drdpt";
            this.Drdpt.Size = new System.Drawing.Size(0, 29);
            this.Drdpt.TabIndex = 180;
            // 
            // Drname
            // 
            this.Drname.AutoSize = true;
            this.Drname.BackColor = System.Drawing.Color.Transparent;
            this.Drname.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drname.ForeColor = System.Drawing.Color.Teal;
            this.Drname.Location = new System.Drawing.Point(692, 232);
            this.Drname.Name = "Drname";
            this.Drname.Size = new System.Drawing.Size(0, 29);
            this.Drname.TabIndex = 179;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(501, 422);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(164, 29);
            this.label9.TabIndex = 178;
            this.label9.Text = "Visiting Hours:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Teal;
            this.label11.Location = new System.Drawing.Point(587, 232);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 29);
            this.label11.TabIndex = 174;
            this.label11.Text = "Name:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(554, 487);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 29);
            this.label8.TabIndex = 177;
            this.label8.Text = "Chamber:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(514, 357);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(153, 29);
            this.label6.TabIndex = 176;
            this.label6.Text = "Visiting Days:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(528, 288);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 29);
            this.label3.TabIndex = 175;
            this.label3.Text = "Department:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Logoutpicbox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.Givetreatmentpicbox);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Aptlistpicbox);
            this.panel1.Controls.Add(this.Doctorlb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(215, 746);
            this.panel1.TabIndex = 187;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Teal;
            this.pictureBox4.Image = global::HMA.Properties.Resources.L;
            this.pictureBox4.Location = new System.Drawing.Point(39, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(101, 101);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(82, 659);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "Logout";
            // 
            // Logoutpicbox
            // 
            this.Logoutpicbox.Image = global::HMA.Properties.Resources.logout;
            this.Logoutpicbox.Location = new System.Drawing.Point(21, 633);
            this.Logoutpicbox.Name = "Logoutpicbox";
            this.Logoutpicbox.Size = new System.Drawing.Size(48, 67);
            this.Logoutpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logoutpicbox.TabIndex = 13;
            this.Logoutpicbox.TabStop = false;
            this.Logoutpicbox.Click += new System.EventHandler(this.Logoutpicbox_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 11.8F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(83, 350);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 44);
            this.label5.TabIndex = 10;
            this.label5.Text = "Give \r\nTreatment";
            // 
            // Givetreatmentpicbox
            // 
            this.Givetreatmentpicbox.Image = global::HMA.Properties.Resources.prescription;
            this.Givetreatmentpicbox.Location = new System.Drawing.Point(21, 334);
            this.Givetreatmentpicbox.Name = "Givetreatmentpicbox";
            this.Givetreatmentpicbox.Size = new System.Drawing.Size(48, 74);
            this.Givetreatmentpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Givetreatmentpicbox.TabIndex = 9;
            this.Givetreatmentpicbox.TabStop = false;
            this.Givetreatmentpicbox.Click += new System.EventHandler(this.Givetreatmentpicbox_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 11.8F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(75, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 44);
            this.label4.TabIndex = 8;
            this.label4.Text = "Appoinmnet\r\n        list";
            // 
            // Aptlistpicbox
            // 
            this.Aptlistpicbox.Image = global::HMA.Properties.Resources.files;
            this.Aptlistpicbox.Location = new System.Drawing.Point(21, 205);
            this.Aptlistpicbox.Name = "Aptlistpicbox";
            this.Aptlistpicbox.Size = new System.Drawing.Size(48, 74);
            this.Aptlistpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Aptlistpicbox.TabIndex = 7;
            this.Aptlistpicbox.TabStop = false;
            this.Aptlistpicbox.Click += new System.EventHandler(this.Aptlistpicbox_Click);
            // 
            // Doctorlb
            // 
            this.Doctorlb.AutoSize = true;
            this.Doctorlb.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Doctorlb.ForeColor = System.Drawing.Color.White;
            this.Doctorlb.Location = new System.Drawing.Point(46, 132);
            this.Doctorlb.Name = "Doctorlb";
            this.Doctorlb.Size = new System.Drawing.Size(83, 25);
            this.Doctorlb.TabIndex = 4;
            this.Doctorlb.Text = "Doctor";
            // 
            // Doctor_UI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 746);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Drhcham);
            this.Controls.Add(this.Drvhrs);
            this.Controls.Add(this.Drvdays);
            this.Controls.Add(this.Drdpt);
            this.Controls.Add(this.Drname);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Doctor_UI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doctor_UI";
            this.Load += new System.EventHandler(this.Doctor_UI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logoutpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Givetreatmentpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aptlistpicbox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Drhcham;
        private System.Windows.Forms.Label Drvhrs;
        private System.Windows.Forms.Label Drvdays;
        private System.Windows.Forms.Label Drdpt;
        private System.Windows.Forms.Label Drname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox Logoutpicbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox Givetreatmentpicbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox Aptlistpicbox;
        private System.Windows.Forms.Label Doctorlb;
    }
}