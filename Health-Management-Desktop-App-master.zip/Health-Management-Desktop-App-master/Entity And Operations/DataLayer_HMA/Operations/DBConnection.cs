﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer_HMA.Operations
{
    public class DBConnection
    {
        public string connect = "Data Source=JAWAD;Initial Catalog=HealthManagementAppDB;Integrated Security=True";
    }
}
